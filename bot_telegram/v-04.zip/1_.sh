#!/bin/bash

# Memanggil file konfigurasi
P_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source $P_DIR/0.sh

# 1. Mengambil Data Sistem
OS_INFO=$(cat /etc/os-release | grep "PRETTY_NAME" | cut -d'"' -f2)
IP_PUB=$(curl -s https://ifconfig.me)
WAKTU=$(date +"%d-%m-%Y %H:%M:%S")
SUHU=$(vcgencmd measure_temp | cut -d'=' -f2)
UPTIME=$(uptime -p | sed 's/up //')
DISK_INFO=$(df -h / | awk 'NR==2 {print $3 " / " $2 " (" $5 ")"}')
RAM=$(free -m | awk '/Mem:/ { print $3 "/" $2 "MB" }')
CPU_LOAD=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')

# 2. Mengambil IP LAN (eth0) & Membuat Link
IP_LAN=$(ip -4 addr show eth0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
if [ -n "$IP_LAN" ]; then
    LINK_LAN="[http://$IP_LAN](http://$IP_LAN)"
else
    LINK_LAN="*Disconnected*"
fi

# 3. Mengambil IP WIFI (wlan0) & Membuat Link
IP_WIFI=$(ip -4 addr show wlan0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
if [ -n "$IP_WIFI" ]; then
    LINK_WIFI="[http://$IP_WIFI](http://$IP_WIFI)"
else
    LINK_WIFI="*Disconnected*"
fi

# 4. Menyusun Pesan Markdown
PESAN="⚡️⚡️⚡️ *SYSTEM - $DEVICE_NAME* ⚡️⚡️⚡️
===========================
🖥️ *OS* : \`$OS_INFO\`
📅 *Waktu* : \`$WAKTU\`
📈 *CPU Load* : \`$CPU_LOAD%\`
🌡️ *Suhu CPU* : \`$SUHU\`
⏱️ *Uptime* : \`$UPTIME\`
💾 *RAM Usage* : \`$RAM\`
💽 *Disk* : \`$DISK_INFO\`
===========================
📡 *KONEKSI JARINGAN*
🔌 *LAN (eth0)* : $LINK_LAN
📶 *WiFi (wlan)* : $LINK_WIFI
🌐 *IP PUB* : $IP_PUB
===========================
🤖 *Status*: System Normal ✅"

# 3. Logika penentuan target (Grup atau Chat Pribadi)
# Jika GROUP_ID tidak kosong, gunakan GROUP_ID. Jika kosong, gunakan CHAT_ID.
if [ -n "$GROUP_ID" ]; then
    TARGET_ID="$GROUP_ID"
else
    TARGET_ID="$CHAT_ID"
fi

# 4. Mengirim ke Telegram menggunakan TARGET_ID yang sudah ditentukan
curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
    -d chat_id="$TARGET_ID" \
    -d text="$PESAN" \
    -d parse_mode="Markdown" > /dev/null
